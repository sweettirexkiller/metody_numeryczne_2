function [c] = mnozenie_R_razy_wektor(p,q,s,x)

end

